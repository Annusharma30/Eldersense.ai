import Link from "next/link"

export default function SettingsPage() {
  return (
    <main className="mx-auto max-w-md p-4 pb-24">
      <header className="mb-6 flex items-center gap-3">
        <Link href="/" className="rounded-full bg-secondary px-3 py-2 text-sm font-semibold">
          Back
        </Link>
        <h1 className="text-2xl font-extrabold">Settings</h1>
      </header>

      <section className="space-y-4">
        <div className="rounded-2xl bg-card p-4 shadow-sm">
          <label className="flex items-center justify-between">
            <span className="text-lg font-semibold">Large Text</span>
            <input type="checkbox" className="h-6 w-10 accent-[var(--primary)]" defaultChecked />
          </label>
        </div>
        <div className="rounded-2xl bg-card p-4 shadow-sm">
          <label className="flex items-center justify-between">
            <span className="text-lg font-semibold">High Contrast</span>
            <input type="checkbox" className="h-6 w-10 accent-[var(--primary)]" />
          </label>
        </div>
        <div className="rounded-2xl bg-card p-4 shadow-sm">
          <label className="flex items-center justify-between">
            <span className="text-lg font-semibold">Voice Onboarding</span>
            <input type="checkbox" className="h-6 w-10 accent-[var(--primary)]" defaultChecked />
          </label>
        </div>
      </section>
    </main>
  )
}
