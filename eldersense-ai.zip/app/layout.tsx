import type React from "react"
import type { Metadata } from "next"
import { Nunito } from "next/font/google"
import { GeistMono } from "geist/font/mono"
import { Analytics } from "@vercel/analytics/next"
import { Suspense } from "react"
import BottomNav from "@/components/bottom-nav"
import "./globals.css"

export const metadata: Metadata = {
  title: "ElderSense AI",
  description: "An elder-friendly, safe news companion",
  generator: "v0.app",
}

const nunito = Nunito({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-nunito",
})

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${nunito.variable} ${GeistMono.variable} antialiased`}>
      <body className="font-sans bg-background text-foreground">
        <Suspense fallback={null}>
          <header className="hidden"></header>
          <div className="min-h-dvh pb-24">{children}</div>
          <BottomNav />
          <Analytics />
        </Suspense>
      </body>
    </html>
  )
}
