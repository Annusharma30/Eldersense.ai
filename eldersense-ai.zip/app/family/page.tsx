import Link from "next/link"

export default function FamilySharePage() {
  const contacts = ["Alex (Daughter)", "Sam (Grandson)", "Pat (Neighbor)"]
  return (
    <main className="mx-auto max-w-md p-4 pb-24">
      <header className="mb-6 flex items-center gap-3">
        <Link href="/" className="rounded-full bg-secondary px-3 py-2 text-sm font-semibold">
          Back
        </Link>
        <h1 className="text-2xl font-extrabold">Family Share</h1>
      </header>

      <section className="space-y-3">
        {contacts.map((c) => (
          <label key={c} className="flex items-center justify-between rounded-2xl bg-card p-4 shadow-sm">
            <span className="text-lg font-semibold">{c}</span>
            <input
              type="checkbox"
              className="h-6 w-6 accent-[var(--primary)]"
              aria-label={`Share with ${c}`}
              defaultChecked
            />
          </label>
        ))}
        <button className="w-full rounded-2xl bg-primary px-4 py-3 text-lg font-semibold text-primary-foreground">
          Share Latest Article
        </button>
      </section>
    </main>
  )
}
