import { FeatureCard } from "@/components/feature-card"
import { NewsCard } from "@/components/news-card"
import { FeedbackSlider } from "@/components/feedback-slider"
import Image from "next/image"

export default function HomePage() {
  return (
    <main className="mx-auto max-w-md p-4 pb-24">
      {/* Top curved header echoing the reference */}
      <section className="relative mb-6 overflow-hidden rounded-b-3xl bg-primary px-4 pb-6 pt-10 text-primary-foreground">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-balance text-2xl font-extrabold">Hi, Melani</h1>
            <p className="mt-1 text-sm opacity-90">Your safe news plan for today</p>
          </div>
          <Image
            src="/images/assistant-hero.jpg"
            alt="Friendly assistant"
            width={72}
            height={72}
            className="h-16 w-16 rounded-2xl object-cover ring-1 ring-white/40 shadow-sm"
          />
        </div>

        <div className="mt-4 inline-flex items-center gap-3 rounded-2xl bg-card/90 px-4 py-3 text-foreground shadow-sm">
          <span className="rounded-full bg-primary/20 px-3 py-1 text-sm font-semibold text-foreground">
            32% complete
          </span>
          <span className="text-sm text-muted-foreground">2 of 5 read</span>
        </div>
      </section>

      {/* Quick features */}
      <section aria-label="Quick features" className="mb-6 grid grid-cols-2 gap-3">
        <FeatureCard
          title="Safe Feed"
          desc="Curated, calm news"
          href="/article"
          iconUrl="/news-feed-icon.png"
          intent="primary"
        />
        <FeatureCard title="Simplified News" desc="Easy summaries" href="/article" iconUrl="/simple-text-icon.jpg" />
        <FeatureCard title="Voice Mode" desc="Listen hands-free" href="/voice" iconUrl="/voice-icon.jpg" />
        <FeatureCard title="Family Share" desc="Share safely" href="/family" iconUrl="/family-share-icon.jpg" />
      </section>

      {/* AI tools */}
      <section aria-label="AI tools" className="mb-6">
        <h2 className="sr-only">AI tools</h2>
        <div className="grid grid-cols-2 gap-3">
          <FeatureCard
            title="Text Analysis"
            href="/features/text-analysis"
            iconUrl="/minimal-magnifying-glass-with-text-lines-icon.jpg"
            size="sm"
          />
          <FeatureCard
            title="Summarize & Simplify"
            href="/features/summarize"
            iconUrl="/minimal-document-with-sparkle-icon.jpg"
            size="sm"
          />
          <FeatureCard
            title="Safety Filter"
            href="/features/safety"
            iconUrl="/minimal-shield-with-alert-icon.jpg"
            size="sm"
          />
          <FeatureCard
            title="Translation"
            href="/features/translate"
            iconUrl="/minimal-globe-translation-icon.jpg"
            size="sm"
          />
        </div>
      </section>

      {/* Safe news cards */}
      <section aria-label="Today’s safe news" className="mb-6 space-y-4">
        <NewsCard
          title="Local Park Adds Benches and Ramps"
          summary="The city added new benches, ramps, and lights to make the park easier and safer for everyone."
          bias="safe"
        />
        <NewsCard
          title="New Health Tips from Community Clinic"
          summary="Doctors share simple daily routines to improve sleep and energy."
          bias="neutral"
        />
      </section>

      {/* Feedback trainer */}
      <FeedbackSlider />
    </main>
  )
}
