import Link from "next/link"
import { VoiceControls } from "@/components/voice-controls"

export default function VoiceModePage() {
  return (
    <main className="mx-auto max-w-md p-4 pb-24">
      <header className="mb-6 flex items-center gap-3">
        <Link href="/" className="rounded-full bg-secondary px-3 py-2 text-sm font-semibold">
          Back
        </Link>
        <h1 className="text-2xl font-extrabold">Voice Mode</h1>
      </header>

      <section className="rounded-3xl bg-card p-6 text-center shadow-sm">
        <p id="voice-label" className="mb-4 text-lg font-semibold">
          Now reading: Local Park Adds Benches and Ramps
        </p>
        <div className="mb-6 flex justify-center">
          <VoiceControls labelId="voice-label" />
        </div>
        <p className="text-sm text-muted-foreground leading-relaxed">
          You can lock the screen and keep listening. Use the big Play/Pause button anytime.
        </p>
      </section>
    </main>
  )
}
