import { VoiceControls } from "@/components/voice-controls"
import { BiasIndicator } from "@/components/bias-indicator"
import Link from "next/link"

export default function ArticlePage() {
  return (
    <main className="mx-auto max-w-md p-4 pb-24">
      <header className="mb-4 flex items-center gap-3">
        <Link href="/" className="rounded-full bg-secondary px-3 py-2 text-sm font-semibold">
          Back
        </Link>
        <h1 className="text-2xl font-extrabold">Simplified Article</h1>
      </header>

      <div className="mb-3 flex items-center justify-between">
        <BiasIndicator level="safe" />
        <span className="text-sm text-muted-foreground">3 min read</span>
      </div>

      <p id="article-label" className="mb-4 text-pretty leading-relaxed">
        The city improved the neighborhood park to make it easier to enjoy. They added benches for resting, ramps for
        easier walking, and more lights to help everyone feel safe in the evening.
      </p>

      <div className="mb-6">
        <VoiceControls labelId="article-label" />
      </div>

      <div className="flex items-center gap-3">
        <button className="rounded-xl bg-secondary px-4 py-2 text-sm font-semibold">Explain Simply</button>
        <button className="rounded-xl bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">
          Share with Family
        </button>
      </div>
    </main>
  )
}
