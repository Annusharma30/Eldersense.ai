import Link from "next/link"

export default function Page() {
  return (
    <main className="p-5">
      <h1 className="text-2xl font-bold mb-2">Summarize & Simplify</h1>
      <p className="text-muted-foreground leading-6">
        Simplify complex content and generate short summaries (T5/BART/Pegasus).
      </p>
      <div className="mt-6">
        <Link href="/" className="underline">
          Back to Home
        </Link>
      </div>
    </main>
  )
}
