import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function FeaturesTechPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl md:text-4xl font-sans font-semibold text-[var(--foreground)] text-balance">
        Purpose, Technology & APIs
      </h1>
      <p className="text-[color:var(--muted-foreground)] leading-relaxed text-lg">
        These AI capabilities power ElderSense to simplify, explain, and voice-read content for seniors.
      </p>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="rounded-2xl">
          <CardHeader>
            <CardTitle className="text-2xl">Text Analysis</CardTitle>
          </CardHeader>
          <CardContent className="text-lg leading-relaxed">
            <p className="font-medium">Bias, Sentiment, Emotion</p>
            <p className="mt-2">
              Hugging Face Transformers (e.g., bert-base-uncased, distilbert-base-uncased, roberta-base) to detect
              emotional tone, bias, and sentiment.
            </p>
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardHeader>
            <CardTitle className="text-2xl">Summarization & Simplification</CardTitle>
          </CardHeader>
          <CardContent className="text-lg leading-relaxed">
            <p className="font-medium">T5 / BART / Pegasus</p>
            <p className="mt-2">Generates short summaries and simplifies complex text for easy understanding.</p>
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardHeader>
            <CardTitle className="text-2xl">Toxicity & Misinformation</CardTitle>
          </CardHeader>
          <CardContent className="text-lg leading-relaxed">
            <p className="font-medium">Google Perspective, OpenAI moderation, HuggingFace toxicity</p>
            <p className="mt-2">Automatically filters harmful or misleading content to keep reading safe.</p>
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardHeader>
            <CardTitle className="text-2xl">Language Translation</CardTitle>
          </CardHeader>
          <CardContent className="text-lg leading-relaxed">
            <p className="font-medium">Google Translate API or IndicTrans2</p>
            <p className="mt-2">Supports Indian regional languages to make content more accessible.</p>
          </CardContent>
        </Card>

        <Card className="rounded-2xl md:col-span-2">
          <CardHeader>
            <CardTitle className="text-2xl">Voice Narration</CardTitle>
          </CardHeader>
          <CardContent className="text-lg leading-relaxed">
            <p className="font-medium">gTTS (Google Text-to-Speech) or Azure Speech Services</p>
            <p className="mt-2">Converts simplified text into natural voice for seniors with low vision.</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
