import Link from "next/link"

export default function Page() {
  return (
    <main className="p-5">
      <h1 className="text-2xl font-bold mb-2">Language Translation</h1>
      <p className="text-muted-foreground leading-6">
        Translate for regional accessibility (Google Translate, IndicTrans2).
      </p>
      <div className="mt-6">
        <Link href="/" className="underline">
          Back to Home
        </Link>
      </div>
    </main>
  )
}
