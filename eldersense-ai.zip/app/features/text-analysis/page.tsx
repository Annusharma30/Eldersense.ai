import Link from "next/link"

export default function Page() {
  return (
    <main className="p-5">
      <h1 className="text-2xl font-bold mb-2">Text Analysis</h1>
      <p className="text-muted-foreground leading-6">
        Detect bias, sentiment, and emotion using Transformers (BERT/DistilBERT/Roberta).
      </p>
      <div className="mt-6">
        <Link href="/" className="underline">
          Back to Home
        </Link>
      </div>
    </main>
  )
}
