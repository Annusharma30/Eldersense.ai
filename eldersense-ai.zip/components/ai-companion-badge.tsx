"use client"
import Image from "next/image"

export default function AICompanionBadge() {
  return (
    <div className="flex items-center gap-2 rounded-full bg-secondary/70 px-3 py-1 shadow-sm">
      <Image
        src="/images/logo-nirvana.jpg"
        alt="Nirvana team logo"
        width={28}
        height={28}
        className="h-7 w-7 object-contain"
      />
      <span className="text-sm font-semibold">ElderSense</span>
    </div>
  )
}
