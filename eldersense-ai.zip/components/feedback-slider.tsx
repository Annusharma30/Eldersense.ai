"use client"
import { useState } from "react"

export function FeedbackSlider() {
  const [value, setValue] = useState(2) // 1..3
  const labels = ["Too Complex", "Just Right", "Too Simple"]
  return (
    <div className="rounded-2xl bg-secondary p-4 shadow-sm">
      <div className="mb-2 text-base font-semibold">Was this easy to understand?</div>
      <div className="flex items-center gap-3">
        {labels.map((l, i) => {
          const idx = i + 1
          const active = value === idx
          return (
            <button
              key={l}
              onClick={() => setValue(idx)}
              className={`flex-1 rounded-xl px-3 py-2 text-sm ${
                active ? "bg-primary text-primary-foreground" : "bg-card"
              }`}
              aria-pressed={active}
            >
              {l}
            </button>
          )
        })}
      </div>
    </div>
  )
}
