import type * as React from "react"

type Props = {
  title: string
  tech: string
  Icon: React.ComponentType<React.SVGProps<SVGSVGElement>>
  accent?: "primary" | "neutral"
}

export default function AIFeatureCard({ title, tech, Icon, accent = "primary" }: Props) {
  const iconClasses = accent === "primary" ? "bg-primary/10 text-primary" : "bg-muted text-foreground"
  return (
    <article
      className="rounded-2xl bg-card text-card-foreground p-5 md:p-6 shadow-sm focus-within:ring-2 focus-within:ring-primary"
      aria-labelledby={`${title.replace(/\s+/g, "-").toLowerCase()}-label`}
    >
      <div className={`w-16 h-16 md:w-18 md:h-18 rounded-xl ${iconClasses} flex items-center justify-center mb-4`}>
        <Icon className="w-9 h-9 md:w-10 md:h-10" />
      </div>
      <h3
        id={`${title.replace(/\s+/g, "-").toLowerCase()}-label`}
        className="text-lg md:text-xl font-semibold text-balance"
      >
        {title}
      </h3>
      <p className="mt-1 text-sm md:text-base leading-6 text-muted-foreground">{tech}</p>
    </article>
  )
}
