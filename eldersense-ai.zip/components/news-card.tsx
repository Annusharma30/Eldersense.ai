"use client"
import { useState } from "react"
import { BiasIndicator } from "./bias-indicator"
import { VoiceControls } from "./voice-controls"

type Props = {
  title: string
  summary: string
  bias: "safe" | "neutral" | "biased"
}

export function NewsCard({ title, summary, bias }: Props) {
  const [explained, setExplained] = useState(false)

  return (
    <article className="rounded-2xl bg-card p-4 shadow-sm">
      <header className="mb-2 flex items-start justify-between gap-3">
        <h3 className="text-xl font-bold text-pretty">{title}</h3>
        <BiasIndicator level={bias} />
      </header>
      <p className="mb-4 leading-relaxed text-muted-foreground">
        {explained
          ? "This is a simplified explanation focusing on the main idea and avoiding jargon. It summarizes the who, what, and why in two sentences for clarity."
          : summary}
      </p>
      <div className="mb-4">
        <VoiceControls />
      </div>
      <div className="flex items-center gap-3">
        <button
          onClick={() => setExplained((e) => !e)}
          className="rounded-xl bg-secondary px-4 py-2 text-sm font-semibold"
        >
          {explained ? "Show Original" : "Explain Simply"}
        </button>
        <button className="rounded-xl bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">
          Share with Family
        </button>
      </div>
    </article>
  )
}
