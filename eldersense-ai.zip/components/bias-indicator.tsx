type Level = "safe" | "neutral" | "biased"

export function BiasIndicator({ level }: { level: Level }) {
  const label = level === "safe" ? "Safe" : level === "neutral" ? "Neutral" : "Biased"
  const color = level === "safe" ? "bg-primary" : level === "neutral" ? "bg-accent" : "bg-destructive"
  return (
    <div className="flex items-center gap-2">
      <span className={`inline-block h-3 w-3 rounded-full ${color}`} aria-hidden="true" />
      <span className="sr-only">Bias indicator: {label}</span>
      <span className="text-xs">{label}</span>
    </div>
  )
}
