"use client"
import { useState } from "react"
import { Play, Pause, Volume2 } from "lucide-react"

export function VoiceControls({ labelId }: { labelId?: string }) {
  const [playing, setPlaying] = useState(false)
  return (
    <div className="flex items-center gap-4">
      <button
        className="rounded-full bg-primary px-6 py-3 text-primary-foreground text-lg font-semibold"
        onClick={() => setPlaying((p) => !p)}
        aria-pressed={playing}
        aria-describedby={labelId}
      >
        <span className="inline-flex items-center gap-2">
          {playing ? <Pause aria-hidden /> : <Play aria-hidden />}
          {playing ? "Pause" : "Play"}
        </span>
      </button>
      <div aria-hidden className="flex items-center gap-2 text-muted-foreground">
        <Volume2 />
        <span className="text-sm">Voice On</span>
      </div>
    </div>
  )
}
