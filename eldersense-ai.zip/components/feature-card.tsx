import Link from "next/link"
import { cn } from "@/lib/utils"

type Props = {
  title: string
  desc?: string
  href: string
  iconUrl?: string
  intent?: "primary" | "neutral"
  size?: "sm" | "md" // NEW
}

export function FeatureCard({ title, desc, href, iconUrl, intent = "neutral", size = "md" }: Props) {
  const iconSize = size === "sm" ? "h-8 w-8" : "h-10 w-10" // NEW
  return (
    <Link
      href={href}
      className={cn(
        "rounded-xl p-4 shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
        "hover:bg-secondary",
        intent === "primary" ? "bg-primary/10" : "bg-card",
      )}
      aria-label={title}
    >
      <div className="flex items-center gap-3">
        <img
          src={iconUrl || "/placeholder.svg?height=40&width=40&query=clean%20simple%20icon"}
          alt=""
          className={`${iconSize} rounded-md`} // CHANGED
        />
        <div>
          <p className="text-lg font-semibold leading-6">{title}</p>
          {desc ? <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p> : null}
        </div>
      </div>
    </Link>
  )
}
