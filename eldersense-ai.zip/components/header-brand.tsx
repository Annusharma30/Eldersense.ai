"use client"

import Link from "next/link"

export default function HeaderBrand() {
  return (
    <nav aria-label="Top navigation" className="flex items-center justify-between">
      <div className="flex items-center gap-3">
        <Link
          href="/"
          className="inline-flex items-center gap-2 focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--ring)] rounded-md"
          aria-label="Go to ElderSense home"
        >
          <span className="text-2xl md:text-3xl font-sans font-semibold tracking-tight text-[var(--foreground)]">
            ElderSense
          </span>
          <img
            src="/images/logo-nirvana.jpg"
            alt="Team Nirvana logo"
            className="h-7 w-auto md:h-8 object-contain"
            width={160}
            height={48}
          />
        </Link>
      </div>
    </nav>
  )
}
