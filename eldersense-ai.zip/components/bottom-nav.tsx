"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

const items = [
  { href: "/", label: "Home" },
  { href: "/article", label: "Simple" },
  { href: "/voice", label: "Voice" },
  { href: "/family", label: "Family" },
  { href: "/settings", label: "Settings" },
]

export default function BottomNav() {
  const pathname = usePathname()

  return (
    <nav
      role="navigation"
      aria-label="Main"
      className="fixed inset-x-0 bottom-0 z-50 border-t border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/75"
    >
      <ul className="mx-auto grid max-w-md grid-cols-5">
        {items.map((item) => {
          const active = pathname === item.href
          return (
            <li key={item.href}>
              <Link
                href={item.href}
                className={cn(
                  "flex flex-col items-center justify-center py-3 text-sm font-semibold",
                  active ? "text-foreground" : "text-muted-foreground",
                )}
                aria-current={active ? "page" : undefined}
              >
                <span
                  className={cn("rounded-full px-3 py-1", active ? "bg-primary/30 text-foreground" : "bg-transparent")}
                >
                  {item.label}
                </span>
              </Link>
            </li>
          )
        })}
      </ul>
    </nav>
  )
}
