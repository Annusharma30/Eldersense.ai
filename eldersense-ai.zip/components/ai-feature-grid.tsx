import AIFeatureCard from "./ai-feature-card"
import { IconMagnifyText, IconDocSparkle, IconShieldAlert, IconGlobeTranslate } from "./icons/elder-icons"

export default function AiFeatureGrid() {
  const items = [
    {
      title: "Text Analysis",
      tech: "Hugging Face Transformers (bert/distilbert/roberta) to detect bias, sentiment, and emotion.",
      Icon: IconMagnifyText,
    },
    {
      title: "Summarize & Simplify",
      tech: "T5 / BART / Pegasus to simplify complex content and generate short summaries.",
      Icon: IconDocSparkle,
    },
    {
      title: "Toxicity & Misinformation",
      tech: "Google Perspective, OpenAI moderation, or HF toxicity pipeline to filter harmful content.",
      Icon: IconShieldAlert,
    },
    {
      title: "Language Translation",
      tech: "Google Translate or IndicTrans2 for Indian languages and regional accessibility.",
      Icon: IconGlobeTranslate,
    },
  ] as const

  return (
    <section aria-label="AI Capabilities" className="mt-6 md:mt-8">
      <h2 className="text-xl md:text-2xl font-bold mb-4">AI Capabilities</h2>
      <div className="grid grid-cols-2 gap-4">
        {items.map(({ title, tech, Icon }) => (
          <AIFeatureCard key={title} title={title} tech={tech} Icon={Icon} />
        ))}
      </div>
    </section>
  )
}
