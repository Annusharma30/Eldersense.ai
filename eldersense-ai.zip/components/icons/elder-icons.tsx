import type * as React from "react"

type IconProps = React.SVGProps<SVGSVGElement>

export function IconMagnifyText(props: IconProps) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...props}>
      <g fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
        <rect x="3.5" y="4.5" width="12" height="8" rx="2"></rect>
        <path d="M6 7.5h7M6 10.5h4"></path>
        <circle cx="17.5" cy="16.5" r="3"></circle>
        <path d="M19.7 18.7L21 20"></path>
      </g>
    </svg>
  )
}

export function IconDocSparkle(props: IconProps) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...props}>
      <g fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
        <path d="M7.5 3.5h6l4 4v10a3 3 0 0 1-3 3h-7a3 3 0 0 1-3-3v-11a3 3 0 0 1 3-3Z"></path>
        <path d="M13.5 3.5v4a2 2 0 0 0 2 2h4"></path>
        <path d="M9 13h6M9 16h4"></path>
        <path d="M16.5 10.5l.7-1.4l1.3-.6l-1.3-.6l-.7-1.4l-.6 1.4l-1.4.6l1.4.6z"></path>
      </g>
    </svg>
  )
}

export function IconShieldAlert(props: IconProps) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...props}>
      <g fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
        <path d="M12 3l7 3v5c0 5-3.5 8-7 10c-3.5-2-7-5-7-10V6l7-3Z"></path>
        <path d="M12 8v5"></path>
        <circle cx="12" cy="15.5" r="1"></circle>
      </g>
    </svg>
  )
}

export function IconGlobeTranslate(props: IconProps) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" {...props}>
      <g fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
        <circle cx="10" cy="10" r="7"></circle>
        <path d="M3 10h14M10 3a15.5 15.5 0 0 1 0 14M10 3a15.5 15.5 0 0 0 0 14"></path>
        <path d="M16.5 13.5h5l-2.5 6l-2.5-6Z"></path>
        <path d="M18 16h2"></path>
      </g>
    </svg>
  )
}

export default {
  IconMagnifyText,
  IconDocSparkle,
  IconShieldAlert,
  IconGlobeTranslate,
}
